package com.example.retrofit.models;

import com.google.gson.annotations.SerializedName;

public class Post {

 private int id;
    private String name;
    private String language;
    private String genre;
    private int rating;
    private String date;

    public Post(String name, String language, String genre, int rating, String date) {

        this.name = name;
        this.language = language;
        this.genre = genre;
        this.rating = rating;
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
