package com.example.retrofit.api_interface;

import com.example.retrofit.models.Post;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface JsonPlaceHolder {

    @GET("addMovie")
    Call<List<Post>> getPosts();

    @POST("addMovie")
    Call<Post> createPost(@Body Post post);
}
