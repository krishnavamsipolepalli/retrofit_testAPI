package com.example.retrofit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddMovieActivity extends AppCompatActivity {

    EditText movieName;
    EditText movieRating;
    EditText movieLang;
    EditText movieYear;
    EditText movieGenre;
    Button submit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_movie);
        movieName=findViewById(R.id.MovieName);
        movieRating=findViewById(R.id.MovieRating);
        movieLang=findViewById(R.id.MovieLanguage);
        movieYear=findViewById(R.id.MovieDate);
        movieGenre=findViewById(R.id.MovieGenre);
        submit=findViewById(R.id.sumitBtn);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name=movieName.getText().toString();
                String rating=movieRating.getText().toString();
                String genre=movieGenre.getText().toString();
                String date=movieYear.getText().toString();
                String language=movieLang.getText().toString();
                Intent intent=new Intent(getApplicationContext(),PostMovieActivity.class);
                intent.putExtra("name",name);
                intent.putExtra("rating", rating);
                intent.putExtra("genre", genre);
                intent.putExtra("date", date);
                intent.putExtra("language", language);
                startActivity(intent);

            }
        });

    }
}