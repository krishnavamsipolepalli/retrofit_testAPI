package com.example.retrofit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.retrofit.api_interface.JsonPlaceHolder;
import com.example.retrofit.models.Post;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button addmovie;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addmovie = findViewById(R.id.add_Movie);
        addmovie.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        Intent intent=new Intent(getApplicationContext(),AddMovieActivity.class);
        startActivity(intent);
    }
}