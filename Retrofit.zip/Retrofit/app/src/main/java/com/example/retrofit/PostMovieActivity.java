package com.example.retrofit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.example.retrofit.api_interface.JsonPlaceHolder;
import com.example.retrofit.models.Post;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class PostMovieActivity extends AppCompatActivity {
    TextView textResult;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_movie);
        textResult=findViewById(R.id.text_result);
        Bundle bundle = getIntent().getExtras();
        String name = bundle.getString("name");
        String rating = bundle.getString("rating");
        String genre = bundle.getString("genre");
        String date = bundle.getString("date");
        String language = bundle.getString("language");

        createPosts(name,language,genre,Integer. parseInt(rating),date);
    }
        public void getJson()
        {
            Retrofit retrofit=new Retrofit.Builder()
                    .baseUrl("http://192.168.0.134:3030/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();

            JsonPlaceHolder JsonHolder=retrofit.create(JsonPlaceHolder.class);
            Call<List<Post>> call=JsonHolder.getPosts();

            call.enqueue(new Callback<List<Post>>() {
                @Override
                public void onResponse(Call<List<Post>> call, Response<List<Post>> response) {
                    if(!response.isSuccessful()) {
                        textResult.setText("Code :"+response.code());
                        return;
                    }

                    List<Post>  posts= response.body();
                    for(Post post: posts){
                        String content=" ";
                        content+="Name: "+post.getName()+"\n";
                        content+="Language: "+post.getLanguage()+"\n";
                        content+="Rating: "+post.getRating()+"\n";
                        content+="Date: "+post.getDate() +"\n";
                        content+="Genre: "+post.getGenre() +"\n";
                        textResult.append(content);

                    }
                }

                @Override
                public void onFailure(Call<List<Post>> call, Throwable t) {

                    textResult.setText(t.getMessage());
                }
            });
        }

        public void createPosts(String name,String language,String genre, int rating, String date){

            Post post= new Post(name,language,genre,rating,date);

            Retrofit retrofit=new Retrofit.Builder()
                    .baseUrl("http://192.168.0.134:3030/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();

            JsonPlaceHolder JsonHolder=retrofit.create(JsonPlaceHolder.class);
            Call<Post>  call=JsonHolder.createPost(post);

            call.enqueue(new Callback<Post>() {
                @Override
                public void onResponse(Call<Post> call, Response<Post> response) {
                    if(!response.isSuccessful()) {
                        textResult.setText("Code :"+response.code());
                        return;
                    }

                    Post post= response.body();

                    String content="";
                    content+="Response Code: "+response.code()+"\n";
                    content+="ID: "+post.getId()+"\n";
                    content+="Name: "+post.getName()+"\n";
                    content+="Language: "+post.getLanguage()+"\n";
                    content+="Rating: "+post.getRating()+"\n";
                    content+="Date: "+post.getDate() +"\n";
                    content+="Genre: "+post.getGenre() +"\n";

                    textResult.append(content);


                }

                @Override
                public void onFailure(Call<Post> call, Throwable t) {
                    textResult.setText(t.getMessage());
                }
            });
        }
    }
